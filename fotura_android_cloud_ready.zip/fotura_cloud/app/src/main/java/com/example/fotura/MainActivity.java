package com.example.fotura;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class MainActivity extends Activity {
    LinearLayout root, content, list;
    EditText search;
    ArrayList<Row> rows = new ArrayList<>();
    int blue = Color.rgb(20, 105, 210), darkBlue = Color.rgb(10, 55, 125);
    int textDark = Color.rgb(25, 45, 70), muted = Color.rgb(105, 120, 140);

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(darkBlue); build(); }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density + .5f); }
    TextView tv(String s,float sp,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8),dp(4),dp(8),dp(4)); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    GradientDrawable stroke(int color,int line,int fill,float radius){ GradientDrawable g=bg(fill,radius); g.setStroke(dp(line),color); return g; }
    void margin(View v,int l,int top,int r,int bottom){ ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams(); p.setMargins(dp(l),dp(top),dp(r),dp(bottom)); v.setLayoutParams(p); }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,249,253));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Header
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(18),dp(12),dp(18),dp(18));
        GradientDrawable hg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(8,62,145),Color.rgb(35,135,225)}); hg.setCornerRadii(new float[]{0,0,0,0,dp(28),dp(28),dp(28),dp(28)}); header.setBackground(hg);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView drop=tv("💧",42,Color.WHITE); top.addView(drop,new LinearLayout.LayoutParams(dp(62),dp(62)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setGravity(Gravity.RIGHT); TextView a=tv("نظام الفوترة",25,Color.WHITE); a.setTypeface(null,1); TextView b=tv("للمياه",15,Color.WHITE); b.setAlpha(.9f); titles.addView(a); titles.addView(b); top.addView(titles,new LinearLayout.LayoutParams(0,dp(64),1));
        TextView menu=tv("☰",30,Color.WHITE); menu.setGravity(Gravity.CENTER); top.addView(menu,new LinearLayout.LayoutParams(dp(52),dp(60)));
        header.addView(top);
        TextView sub=tv("إدارة الفواتير والمشتركين بسهولة",14,Color.WHITE); sub.setAlpha(.92f); header.addView(sub,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView meter=tv("عداد مياه   012345   m³     •     إدارة دقيقة للاستهلاك",13,Color.WHITE); meter.setGravity(Gravity.CENTER); meter.setBackground(bg(0x28ffffff,18)); header.addView(meter,new LinearLayout.LayoutParams(-1,dp(42)));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(188)));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(10),dp(14),dp(20)); content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        // Stats
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL); stats.setGravity(Gravity.CENTER_VERTICAL); stats.setPadding(dp(6),dp(8),dp(6),dp(8)); stats.setBackground(bg(Color.WHITE,22));
        addStat(stats,"👥",String.valueOf(rows.size()),"إجمالي المشتركين",0xFFEAF4FF);
        addStat(stats,"🧾",String.valueOf(unpaidCount()),"فواتير غير مدفوعة",0xFFFFF4E8);
        addStat(stats,"📄",String.valueOf(rows.size()),"سجلات مستوردة",0xFFEFF9F3);
        addStat(stats,"💰",fmt(totalArrears()),"إجمالي المتأخرات",0xFFF3EEFF);
        content.addView(stats,new LinearLayout.LayoutParams(-1,dp(92))); margin(stats,0,0,0,10);

        // Search
        search=new EditText(this); search.setSingleLine(true); search.setHint("بحث سريع بالاسم أو رقم العداد أو الباركود"); search.setTextSize(14); search.setTextColor(textDark); search.setHintTextColor(muted); search.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); search.setPadding(dp(18),0,dp(18),0); search.setBackground(stroke(0xFFD8E2EF,1,Color.WHITE,22));
        content.addView(search,new LinearLayout.LayoutParams(-1,dp(52))); margin(search,0,0,0,12);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){render(s.toString());} public void afterTextChanged(Editable e){}});

        TextView quickTitle=tv("اختصارات سريعة",18,textDark); quickTitle.setTypeface(null,1); content.addView(quickTitle,new LinearLayout.LayoutParams(-1,dp(38)));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(3); grid.setUseDefaultMargins(false); content.addView(grid,new LinearLayout.LayoutParams(-1,dp(210))); margin(grid,0,0,0,10);
        addFeature(grid,"📊","استيراد Excel","استيراد ملف المشتركين",0xFFEAF4FF,v->pick());
        addFeature(grid,"👥","المشتركون","عرض والبحث في القائمة",0xFFEAF9F2,v->focusSearch());
        addFeature(grid,"🧾","إصدار فاتورة","إنشاء فاتورة جديدة",0xFFFFF4E6,v->chooseCustomer());
        addFeature(grid,"📈","التقارير","الفواتير والتحصيل",0xFFF2EEFF,v->Toast.makeText(this,"التقارير ستكون متاحة بعد استيراد البيانات",Toast.LENGTH_SHORT).show());
        addFeature(grid,"⚙","الأسعار والشرائح","إدارة أسعار المياه",0xFFFFEEF5,v->showPrices());
        addFeature(grid,"🖨","الفواتير السابقة","عرض الفواتير المحفوظة",0xFFEAF5FF,v->Toast.makeText(this,"سجل الفواتير سيظهر هنا",Toast.LENGTH_SHORT).show());

        TextView recent=tv("أحدث الفواتير",18,textDark); recent.setTypeface(null,1); content.addView(recent,new LinearLayout.LayoutParams(-1,dp(40)));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list,new LinearLayout.LayoutParams(-1,-2)); render("");

        Button quick=new Button(this); quick.setText("🔎   بحث سريع عن مشترك"); quick.setTextSize(16); quick.setTextColor(Color.WHITE); quick.setAllCaps(false); quick.setBackground(bg(blue,24)); quick.setOnClickListener(v->focusSearch()); content.addView(quick,new LinearLayout.LayoutParams(-1,dp(56))); margin(quick,0,12,0,0);

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(4),dp(4),dp(4)); nav.setBackgroundColor(Color.WHITE); addNav(nav,"⚙\nالإعدادات"); addNav(nav,"?\nالمساعدة"); addNav(nav,"⌂\nالرئيسية"); addNav(nav,"🔔\nالإشعارات"); addNav(nav,"⇥\nخروج"); root.addView(nav,new LinearLayout.LayoutParams(-1,dp(68)));
        setContentView(root);
    }

    void addStat(LinearLayout parent,String icon,String number,String label,int fill){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); TextView i=tv(icon,19,blue); i.setGravity(Gravity.CENTER); c.addView(i,new LinearLayout.LayoutParams(-1,dp(26))); TextView n=tv(number,16,textDark); n.setGravity(Gravity.CENTER); n.setTypeface(null,1); c.addView(n,new LinearLayout.LayoutParams(-1,dp(26))); TextView l=tv(label,9,muted); l.setGravity(Gravity.CENTER); c.addView(l,new LinearLayout.LayoutParams(-1,dp(24))); c.setBackground(bg(fill,16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(dp(3),0,dp(3),0); parent.addView(c,p);
    }
    void addFeature(GridLayout grid,String icon,String title,String sub,int fill,View.OnClickListener click){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(dp(6),dp(5),dp(6),dp(5)); c.setBackground(bg(fill,18)); c.setOnClickListener(click);
        TextView i=tv(icon,25,textDark); i.setGravity(Gravity.CENTER); c.addView(i,new LinearLayout.LayoutParams(-1,dp(36))); TextView t=tv(title,13,textDark); t.setGravity(Gravity.CENTER); t.setTypeface(null,1); c.addView(t,new LinearLayout.LayoutParams(-1,dp(27))); TextView s=tv(sub,9,muted); s.setGravity(Gravity.CENTER); c.addView(s,new LinearLayout.LayoutParams(-1,dp(28)));
        GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=dp(98); p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); p.setMargins(dp(4),dp(4),dp(4),dp(4)); grid.addView(c,p);
    }
    void addNav(LinearLayout n,String text){TextView v=tv(text,10,muted);v.setGravity(Gravity.CENTER);n.addView(v,new LinearLayout.LayoutParams(0,-1,1));}
    void focusSearch(){ if(search!=null){search.requestFocus(); ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search,0);} }

    void render(String q){
        if(list==null)return; list.removeAllViews(); int n=0;
        for(Row x:rows){String z=(x.name+" "+x.meter+" "+x.barcode).toLowerCase(Locale.ROOT); if(!q.isEmpty()&&!z.contains(q.toLowerCase(Locale.ROOT)))continue; addRecent(x); if(++n>=12)break;}
        if(n==0){TextView empty=tv(rows.isEmpty()?"لا توجد بيانات بعد — ابدأ باستيراد ملف Excel":"لا توجد نتائج مطابقة للبحث",14,muted); empty.setGravity(Gravity.CENTER); empty.setBackground(bg(Color.WHITE,18)); list.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}
    }
    void addRecent(Row x){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(8),dp(8),dp(8),dp(8)); card.setBackground(bg(Color.WHITE,18));
        TextView amount=tv(fmt(x.arrears)+" ل.س",13,Color.rgb(25,145,90)); amount.setGravity(Gravity.CENTER); amount.setTypeface(null,1); amount.setBackground(bg(0xFFEAF8F0,12)); card.addView(amount,new LinearLayout.LayoutParams(dp(105),dp(42)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setGravity(Gravity.RIGHT); TextView name=tv(x.name.isEmpty()?"مشترك بدون اسم":x.name,14,blue); name.setTypeface(null,1); TextView det=tv("رقم العداد: "+x.meter+"   |   "+x.type,10,muted); info.addView(name); info.addView(det); card.addView(info,new LinearLayout.LayoutParams(0,dp(55),1));
        TextView ico=tv("⌂",23,blue); ico.setGravity(Gravity.CENTER); ico.setBackground(bg(0xFFEAF4FF,20)); card.addView(ico,new LinearLayout.LayoutParams(dp(45),dp(45))); card.setOnClickListener(v->invoice(x)); list.addView(card,new LinearLayout.LayoutParams(-1,dp(70))); margin(card,0,0,0,7);
    }

    void chooseCustomer(){ if(rows.isEmpty()){Toast.makeText(this,"استورد ملف Excel أولاً",Toast.LENGTH_LONG).show();return;} final String[] names=new String[Math.min(rows.size(),100)]; for(int i=0;i<names.length;i++)names[i]=rows.get(i).name+" — عداد "+rows.get(i).meter; new AlertDialog.Builder(this).setTitle("اختر المشترك").setItems(names,(d,w)->invoice(rows.get(w))).show(); }
    int unpaidCount(){int n=0;for(Row r:rows)if(r.arrears>0)n++;return n;}
    double totalArrears(){double s=0;for(Row r:rows)s+=r.arrears;return s;}

    void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK&&d!=null){try{rows=readXlsx(d.getData());Toast.makeText(this,"تم استيراد "+rows.size()+" مشترك بنجاح",Toast.LENGTH_LONG).show();build();}catch(Exception e){Toast.makeText(this,"تعذر قراءة الملف: "+e.getMessage(),Toast.LENGTH_LONG).show();}}}

    void invoice(Row x){
        final LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(8),dp(20),dp(8));
        l.addView(tv("المشترك: "+x.name,18,textDark));l.addView(tv("النوع: "+x.type,14,muted));l.addView(tv("القراءة السابقة: "+x.prev,14,muted));
        EditText cur=new EditText(this);cur.setHint("القراءة الحالية");cur.setInputType(2|8192);cur.setGravity(Gravity.RIGHT);l.addView(cur,new LinearLayout.LayoutParams(-1,dp(52)));l.addView(tv("المتأخرات: "+fmt(x.arrears)+" ل.س",14,muted));TextView out=tv("",16,textDark);l.addView(out);Button calc=new Button(this);calc.setText("احسب الفاتورة");calc.setAllCaps(false);l.addView(calc);calc.setOnClickListener(v->{try{double cv=Double.parseDouble(cur.getText().toString());double pv=Double.parseDouble(x.prev);if(pv<0)throw new Exception("القراءة السابقة غير صالحة");double cons=cv-pv;if(cons<0)throw new Exception("القراءة الحالية أقل من السابقة");double fee=calcFee(x.type,cons);double total=fee+x.arrears;out.setText("الاستهلاك: "+fmt(cons)+" م³\nقيمة الاستهلاك: "+fmt(fee)+" ل.س\nالإجمالي: "+fmt(total)+" ل.س");}catch(Exception e){out.setText("تنبيه: "+e.getMessage());}});
        Button pdf=new Button(this);pdf.setText("حفظ الفاتورة PDF");pdf.setAllCaps(false);l.addView(pdf);pdf.setOnClickListener(v->{try{makePdf(x,cur.getText().toString(),out.getText().toString());}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});
        new AlertDialog.Builder(this).setTitle("فاتورة المشترك").setView(l).setPositiveButton("إغلاق",null).show();
    }
    void showPrices(){new AlertDialog.Builder(this).setTitle("الأسعار والشرائح").setMessage("منزلي:\n1–5 مجاني\n6–15 = 7 ل.س/م³\n16–25 = 15 ل.س/م³\n26–35 = 22 ل.س/م³\n36–50 = 150 ل.س/م³\n51–80 = 400 ل.س/م³ كامل الاستهلاك\n81–120 = 1500 ل.س/م³ كامل الاستهلاك\n121+ = 3000 ل.س/م³ كامل الاستهلاك\n\nتجاري / سياحي:\n1–10 = 1000\n11–60 = 1500\n61+ = 3000").setPositiveButton("حسنًا",null).show();}

    double calcFee(String type,double q){type=type==null?"":type;if(type.contains("منزلي")){if(q<=5)return 0;if(q<=15)return (q-5)*7;if(q<=25)return 10*7+(q-15)*15;if(q<=35)return 10*7+10*15+(q-25)*22;if(q<=50)return 10*7+10*15+10*22+(q-35)*150;if(q<=80)return q*400;if(q<=120)return q*1500;return q*3000;}if(q<=10)return q*1000;if(q<=60)return q*1500;return q*3000;}
    String fmt(double x){return String.format(Locale.US,"%.0f",x);}
    void makePdf(Row x,String cur,String body)throws Exception{PdfDocument p=new PdfDocument();PdfDocument.Page pg=p.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=pg.getCanvas();Paint paint=new Paint();paint.setTextSize(20);paint.setTextAlign(Paint.Align.RIGHT);int y=70;c.drawText("نظام الفوترة",540,y,paint);y+=45;c.drawText("المشترك: "+x.name,540,y,paint);y+=35;c.drawText("رقم العداد: "+x.meter,540,y,paint);y+=35;c.drawText("القراءة السابقة: "+x.prev,540,y,paint);y+=35;c.drawText("القراءة الحالية: "+cur,540,y,paint);y+=50;for(String s:body.split("\\n")){c.drawText(s,540,y,paint);y+=35;}p.finishPage(pg);File f=new File(getExternalFilesDir(null),"فاتورة_"+System.currentTimeMillis()+".pdf");p.writeTo(new FileOutputStream(f));p.close();Toast.makeText(this,"تم حفظ PDF داخل مجلد التطبيق",Toast.LENGTH_LONG).show();}

    static class Row{String name="",type="",meter="",barcode="",prev="-1";double arrears=0;}
    ArrayList<Row> readXlsx(Uri u)throws Exception{InputStream in=getContentResolver().openInputStream(u);ZipInputStream z=new ZipInputStream(in);HashMap<String,byte[]> files=new HashMap<>();ZipEntry e;byte[] buf=new byte[8192];while((e=z.getNextEntry())!=null){ByteArrayOutputStream o=new ByteArrayOutputStream();int k;while((k=z.read(buf))>0)o.write(buf,0,k);files.put(e.getName(),o.toByteArray());}z.close();String shared=xml(files.get("xl/sharedStrings.xml"));ArrayList<String> ss=new ArrayList<>();if(!shared.isEmpty()){Document d=doc(shared);NodeList ns=d.getElementsByTagName("si");for(int i=0;i<ns.getLength();i++)ss.add(ns.item(i).getTextContent());}String sheet=xml(files.get("xl/worksheets/sheet1.xml"));Document d=doc(sheet);NodeList rs=d.getElementsByTagName("row");ArrayList<String[]> data=new ArrayList<>();for(int i=0;i<rs.getLength();i++){NodeList cs=((Element)rs.item(i)).getElementsByTagName("c");String[] row=new String[Math.max(20,cs.getLength()+2)];for(int j=0;j<cs.getLength();j++){Element c=(Element)cs.item(j);String ref=c.getAttribute("r");int col=0;for(char ch:ref.toCharArray())if(Character.isLetter(ch))col=col*26+(Character.toUpperCase(ch)-'A'+1);col--;String v="";NodeList vs=c.getElementsByTagName("v");if(vs.getLength()>0)v=vs.item(0).getTextContent();if("s".equals(c.getAttribute("t"))&&!v.isEmpty())v=ss.get(Integer.parseInt(v));row[col]=v;}data.add(row);}ArrayList<Row> out=new ArrayList<>();if(data.size()<2)return out;String[] h=data.get(0);for(int i=1;i<data.size();i++){String[] a=data.get(i);Row r=new Row();r.name=find(a,h,"الاسم","الكنية","اسم");r.type=find(a,h,"رمز الاحتساب","نوع","الاحتساب");r.meter=find(a,h,"رقم العداد","عداد");r.barcode=find(a,h,"باركود");r.prev=find(a,h,"التأشيرة السابقة","القراءة السابقة");String ar=find(a,h,"إجمالي الفواتير غير المدفوعة","المتأخرات");try{r.arrears=Double.parseDouble(ar.replace(",",""));}catch(Exception ex){}out.add(r);}return out;}
    String find(String[] a,String[] h,String... keys){for(int j=0;j<h.length&&j<a.length;j++){String head=h[j]==null?"":h[j];for(String k:keys)if(head.contains(k))return a[j]==null?"":a[j];}return "";}
    String xml(byte[] b)throws Exception{return b==null?"":new String(b,"UTF-8");}
    Document doc(String s)throws Exception{return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(s.getBytes("UTF-8")));}
}
